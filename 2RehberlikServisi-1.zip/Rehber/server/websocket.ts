// Re-export from modular WebSocket implementation
export * from './websocket/index';