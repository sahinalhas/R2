// Modüler yapıya dönüştürüldü - Artık client/src/pages/surveys/responses/index.tsx kullanılıyor
import { SurveyResponses } from "./surveys/responses";

// Bu dosya geriye dönük uyumluluk için korunmuştur

export default SurveyResponses;