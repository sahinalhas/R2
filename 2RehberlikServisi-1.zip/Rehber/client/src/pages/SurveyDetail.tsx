// Modüler yapıya dönüştürüldü - Artık client/src/pages/surveys/index.tsx kullanılıyor
import { SurveyDetail } from "./surveys";

// Bu dosya geriye dönük uyumluluk için korunmuştur
// Artık modüler yapı ile client/src/pages/surveys klasöründeki bileşenler kullanılmaktadır

export default SurveyDetail;