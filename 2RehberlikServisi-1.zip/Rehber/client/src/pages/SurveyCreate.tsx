import { SurveyCreate } from './surveys/create';

export default SurveyCreate;